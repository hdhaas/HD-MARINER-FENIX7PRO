using Toybox.WatchUi;
using Toybox.Graphics;
using Toybox.System;
using Toybox.Time;
using Toybox.Time.Gregorian;
using Toybox.Math;
using Toybox.Activity;
using Toybox.ActivityMonitor;

// HD Mariner: a 260x260 Garmin fenix 7 Pro MIP watch face.
// All data displayed over the static dial are obtained at runtime.
class HDMarinerView extends WatchUi.WatchFace {
    var _dial;
    var _moon;
    var _moonIndex;
    var _moonIds;
    var _awake;

    function initialize() {
        WatchFace.initialize();
        _dial = WatchUi.loadResource(Rez.Drawables.Dial);
        _moonIndex = -1;
        _moon = null;
        _awake = true;
        _moonIds = [
            Rez.Drawables.Moon00,
            Rez.Drawables.Moon01,
            Rez.Drawables.Moon02,
            Rez.Drawables.Moon03,
            Rez.Drawables.Moon04,
            Rez.Drawables.Moon05,
            Rez.Drawables.Moon06,
            Rez.Drawables.Moon07,
            Rez.Drawables.Moon08,
            Rez.Drawables.Moon09,
            Rez.Drawables.Moon10,
            Rez.Drawables.Moon11,
            Rez.Drawables.Moon12,
            Rez.Drawables.Moon13,
            Rez.Drawables.Moon14,
            Rez.Drawables.Moon15,
            Rez.Drawables.Moon16,
            Rez.Drawables.Moon17,
            Rez.Drawables.Moon18,
            Rez.Drawables.Moon19,
            Rez.Drawables.Moon20,
            Rez.Drawables.Moon21,
            Rez.Drawables.Moon22,
            Rez.Drawables.Moon23,
            Rez.Drawables.Moon24,
            Rez.Drawables.Moon25,
            Rez.Drawables.Moon26,
            Rez.Drawables.Moon27,
            Rez.Drawables.Moon28,
            Rez.Drawables.Moon29
        ];
    }

    function onEnterSleep() {
        _awake = false;
    }

    function onExitSleep() {
        _awake = true;
    }

    function onUpdate(dc) {
        dc.drawBitmap(0, 0, _dial);
        drawMoon(dc);
        drawData(dc);
        drawHands(dc);
    }

    function drawMoon(dc) {
        // Mean synodic month: 29.530588853 days. Known new moon:
        // 2000-01-06 18:14 UTC (Unix 947182440). Approximation only.
        var cycle = 2551443;
        var age = (Time.now().value() - 947182440) % cycle;
        if (age < 0) { age += cycle; }
        var index = ((age * 30) / cycle).toNumber();
        if (index >= 30) { index = 29; }
        if (index != _moonIndex) {
            _moonIndex = index;
            _moon = WatchUi.loadResource(_moonIds[index]);
        }
        if (_moon != null) { dc.drawBitmap(103, 40, _moon); }
    }

    function drawData(dc) {
        var today = Gregorian.info(Time.now(), Time.FORMAT_SHORT);
        dc.setColor(0x101812, Graphics.COLOR_TRANSPARENT);
        dc.drawText(210, 116, Graphics.FONT_MEDIUM, today.day.format("%d"), Graphics.TEXT_JUSTIFY_CENTER);

        var steps = null;
        var stepGoal = null;
        var monitor = ActivityMonitor.getInfo();
        if (monitor != null) {
            steps = monitor.steps;
            stepGoal = monitor.stepGoal;
        }
        var heartRate = null;
        var activity = Activity.getActivityInfo();
        if (activity != null) { heartRate = activity.currentHeartRate; }
        if (heartRate == null && (ActivityMonitor has :getHeartRateHistory)) {
            var history = ActivityMonitor.getHeartRateHistory(1, true);
            if (history != null) {
                var sample = history.next();
                if (sample != null && sample.heartRate != ActivityMonitor.INVALID_HR_SAMPLE) {
                    heartRate = sample.heartRate;
                }
            }
        }
        // Show dash, never an invented numerical sensor value.
        dc.setColor(0xE8EEDA, Graphics.COLOR_TRANSPARENT);
        dc.drawText(80, 177, Graphics.FONT_MEDIUM,
                    heartRate == null ? "--" : heartRate.format("%d"),
                    Graphics.TEXT_JUSTIFY_CENTER);
        dc.drawText(180, 179, Graphics.FONT_SMALL, formatSteps(steps),
                    Graphics.TEXT_JUSTIFY_CENTER);

        // Live step-goal ring; red HR ring scales between 40 and 160 bpm.
        if (steps != null && stepGoal != null && stepGoal > 0) {
            var frac = (steps.toFloat() / stepGoal).toFloat();
            if (frac > 1.0) { frac = 1.0; }
            if (frac < 0.0) { frac = 0.0; }
            drawProgress(dc, 180, 174, 27, frac, 0x11AA55);
        }
        if (heartRate != null) {
            var hrFrac = (heartRate.toFloat() - 40.0) / 120.0;
            if (hrFrac > 1.0) { hrFrac = 1.0; }
            if (hrFrac < 0.0) { hrFrac = 0.0; }
            drawProgress(dc, 80, 174, 27, hrFrac, 0xEE3036);
        }
    }

    function formatSteps(steps) {
        if (steps == null) { return "--"; }
        if (steps < 1000) { return steps.format("%d"); }
        // Use small thousands separators, e.g., 8.432.
        if (steps < 1000000) {
            return (steps / 1000).toNumber().format("%d") + "." +
                (steps % 1000).format("%03d");
        }
        return steps.format("%d");
    }

    function drawProgress(dc, cx, cy, radius, fraction, rgb) {
        if (fraction <= 0.0) { return; }
        dc.setColor(rgb, Graphics.COLOR_TRANSPARENT);
        dc.setPenWidth(3);
        var segments = (fraction * 24.0).toNumber();
        for (var i = 0; i < segments; i++) {
            var a = Math.toRadians(145.0 + i * (250.0 / 24.0));
            var b = Math.toRadians(145.0 + (i + 1) * (250.0 / 24.0));
            dc.drawLine(cx + radius * Math.cos(a), cy + radius * Math.sin(a),
                        cx + radius * Math.cos(b), cy + radius * Math.sin(b));
        }
        dc.setPenWidth(1);
    }

    function drawHands(dc) {
        var t = System.getClockTime();
        var hourAngle = (t.hour % 12) * 30.0 + t.min * 0.5;
        var minuteAngle = t.min * 6.0 + t.sec * 0.1;
        hand(dc, hourAngle, 51, 5, 0xB8C8BA);
        hand(dc, minuteAngle, 79, 3, 0xD8E7D5);
        if (_awake) {
            // Smooth red second hand while the face is active.
            var secAngle = Math.toRadians(t.sec * 6.0 - 90.0);
            dc.setColor(0xE65B49, Graphics.COLOR_TRANSPARENT);
            dc.setPenWidth(1);
            dc.drawLine(130 - 14 * Math.cos(secAngle), 130 - 14 * Math.sin(secAngle),
                        130 + 91 * Math.cos(secAngle), 130 + 91 * Math.sin(secAngle));
        }
        dc.setColor(0x151C16, Graphics.COLOR_TRANSPARENT);
        dc.fillCircle(130, 130, 5);
        dc.setColor(0xD5DDD1, Graphics.COLOR_TRANSPARENT);
        dc.fillCircle(130, 130, 3);
    }

    function hand(dc, degrees, length, halfWidth, col) {
        var a = Math.toRadians(degrees - 90.0);
        var ux = Math.cos(a);
        var uy = Math.sin(a);
        var vx = -uy;
        var vy = ux;
        dc.setColor(0x161D18, Graphics.COLOR_TRANSPARENT);
        dc.fillPolygon([
            [130 - 9 * ux - (halfWidth+1) * vx, 130 - 9 * uy - (halfWidth+1) * vy],
            [130 + length * ux - (halfWidth+1) * vx/2, 130 + length * uy - (halfWidth+1) * vy/2],
            [130 + (length+6) * ux, 130 + (length+6) * uy],
            [130 + length * ux + (halfWidth+1) * vx/2, 130 + length * uy + (halfWidth+1) * vy/2],
            [130 - 9 * ux + (halfWidth+1) * vx, 130 - 9 * uy + (halfWidth+1) * vy]
        ]);
        dc.setColor(col, Graphics.COLOR_TRANSPARENT);
        dc.fillPolygon([
            [130 - 8 * ux - halfWidth * vx, 130 - 8 * uy - halfWidth * vy],
            [130 + length * ux - halfWidth * vx/2, 130 + length * uy - halfWidth * vy/2],
            [130 + (length+5) * ux, 130 + (length+5) * uy],
            [130 + length * ux + halfWidth * vx/2, 130 + length * uy + halfWidth * vy/2],
            [130 - 8 * ux + halfWidth * vx, 130 - 8 * uy + halfWidth * vy]
        ]);
    }
}
