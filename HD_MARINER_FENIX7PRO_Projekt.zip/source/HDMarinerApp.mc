using Toybox.Application;
using Toybox.WatchUi;

class HDMarinerApp extends Application.AppBase {
    function initialize() { AppBase.initialize(); }
    function getInitialView() { return [ new HDMarinerView() ]; }
}
