# HD Mariner — Garmin fenix 7 Pro

Eigenes **funktionales** analoges Zifferblatt (Monkey C, Connect IQ 5.2).

## Anzeige
- Analoge Uhr mit Live-Zeigern (Sekundenzeiger nur bei aktivem Display)
- Mondphase aus 29,530588853 Tagen berechnet, ca.-Anzeige
- Aktuelles lokales Datum bei 3 Uhr
- Puls unten links: aktuelle Messung, ersatzweise letzter verfügbarer Wert, `--` falls unbekannt
- Schritte seit Mitternacht unten rechts, grüner Fortschrittsbogen relativ zum Garmin-Schrittziel

Die statische Dial-Grafik ist eine neu erstellte, verkleinerte 260x260-MIP-Version des grünen Taucheruhr-Designs. Keine festen Werte werden als Daten ausgegeben.

## Einfacher Build mit GitHub (Handy)
1. **Neues LEERES** GitHub-Repository erstellen, z.B. `HD-MARINER-FENIX7PRO`. Keine README automatisch erzeugen.
2. Alle Inhalte **aus der ZIP** ins Stammverzeichnis hochladen, einschließlich `.github/workflows/build-garmin.yml`. `manifest.xml` und `monkey.jungle` müssen im Repo-Hauptverzeichnis liegen.
3. Auf **Actions** > **Build HD Mariner for fenix 7 Pro** > **Run workflow** klicken. Bei Push auf main startet der Build auch automatisch.
4. Nach erfolgreichem Build unter **Actions** > Build-Lauf > **Artifacts** die Datei `HD_MARINER_FENIX7PRO_PRG.zip` herunterladen und entpacken.
5. Uhr per USB-Datenkabel mit einem Computer verbinden; die enthaltene `.prg` nach **GARMIN/APPS** kopieren. USB-Verbindung sicher trennen und Watchface auf der Uhr auswählen.

**Wichtig:** Die Quell-ZIP ist noch *keine* auf der Uhr installierbare PRG-Datei. Der CI-Workflow muss sie erst kompilieren. Ein Garmin-SDK-Kompilierungstest war in dieser Umgebung nicht möglich. Fehler aus dem ersten GitHub-Action-Lauf bitte mitteilen.

## Lokal kompilieren (wenn Garmin Connect IQ SDK installiert)
```
monkeyc -d fenix7pro -f monkey.jungle -o HD_MARINER.prg -y /PFAD/zu/developer_key.der
```

`fenix7pronowifi` ist ebenfalls eingetragen. Nur private Nutzung: Die Rolex-artige Gestaltung ist nicht mit Rolex verbunden oder offiziell lizenziert. Für eine Veröffentlichung im Connect-IQ-Store Markenhinweise/Gestaltung anpassen.

Quellen: https://developer.garmin.com/connect-iq/compatible-devices/ und https://developer.garmin.com/connect-iq/api-docs/
